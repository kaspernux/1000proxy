1000PROXY Configuration Package

Each folder contains: 
- client.txt            (Primary client config URL)
- subscription.txt      (Subscription link)
- json.txt              (JSON subscription link)
- inbound.txt           (Protocol/host/port summary)
- client-qr.png         (QR for client.txt)
- subscription-qr.png   (QR for subscription.txt, if available)
- json-qr.png           (QR for json.txt, if available)

How to use:
1) Install your preferred client app.
2) Scan client-qr.png or import client.txt.
3) As alternatives, use subscription.txt or json.txt with their QRs.

Security note: Keep these files private.
